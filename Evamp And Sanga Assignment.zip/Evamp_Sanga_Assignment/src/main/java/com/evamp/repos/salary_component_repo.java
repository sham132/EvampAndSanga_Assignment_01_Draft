package com.evamp.repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.evamp.models.salary_component;

@Repository
public interface salary_component_repo extends JpaRepository<salary_component, Long> {

}