package com.evamp.payloads;

import java.util.List;

import java.util.List;

public class Request {
	private String uuid;
	private String fname;
	private List<String> errors;
	private List<PayloadElement> payload;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(List<String> errors) {
		this.errors = errors;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public List<PayloadElement> getPayload() {
		return payload;
	}

	public void setPayload(List<PayloadElement> payload) {
		this.payload = payload;
	}

	// Constructors, getters, and setters
}
