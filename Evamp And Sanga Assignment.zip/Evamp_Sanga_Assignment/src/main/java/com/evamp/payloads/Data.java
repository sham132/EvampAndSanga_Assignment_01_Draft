package com.evamp.payloads;

public class Data {
	private FirstEntity first_entity;
	private SecondEntity second_entity;

	public FirstEntity getFirst_entity() {
		return first_entity;
	}

	public void setFirst_entity(FirstEntity first_entity) {
		this.first_entity = first_entity;
	}

	public SecondEntity getSecond_entity() {
		return second_entity;
	}

	public void setSecond_entity(SecondEntity second_entity) {
		this.second_entity = second_entity;
	}
}



