package com.evamp.payloads;

public class JsonData {
	private String key; // JSON key containing "table_name.column_name"
	private String value; // The value to be inserted

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
