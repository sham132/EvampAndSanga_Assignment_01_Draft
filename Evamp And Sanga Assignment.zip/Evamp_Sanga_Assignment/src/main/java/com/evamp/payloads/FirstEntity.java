package com.evamp.payloads;

public class FirstEntity {
	private String first_field;
	private double second_field;

	public String getFirst_field() {
		return first_field;
	}

	public void setFirst_field(String first_field) {
		this.first_field = first_field;
	}

	public double getSecond_field() {
		return second_field;
	}

	public void setSecond_field(double second_field) {
		this.second_field = second_field;
	}
}