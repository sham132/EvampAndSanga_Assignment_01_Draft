package com.evamp.payloads;

import java.util.List;

public class PayloadElement {
	private String employeeCode;
	private String action;
	private Object data; // Use a suitable type or structure for "data"
	private List<PayComponent> payComponents;

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public List<PayComponent> getPayComponents() {
		return payComponents;
	}

	public void setPayComponents(List<PayComponent> payComponents) {
		this.payComponents = payComponents;
	}

	// Constructors, getters, and setters
}
