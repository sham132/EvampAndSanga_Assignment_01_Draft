package com.evamp.models;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "salary_component")
public class salary_component {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@JoinColumn(name = "person_id", nullable = false)
	private Long person_id;

	private BigDecimal amount;
	private String currency;
	private Date startDate;
	private Date endDate;

	// Constructors
	public salary_component() {
		// Default constructor
	}

	public salary_component(Long person_id, BigDecimal amount, String currency, Date startDate, Date endDate) {
		this.person_id = person_id;
		this.amount = amount;
		this.currency = currency;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	// Getters and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getPerson() {
		return person_id;
	}

	public void setPerson(Long person_id) {
		this.person_id = person_id;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	// Other methods
	@Override
	public String toString() {
		return "SalaryComponent{" + "id=" + id + ", person=" + person_id + ", amount=" + amount + ", currency='"
				+ currency + '\'' + ", startDate=" + startDate + ", endDate=" + endDate + '}';
	}
}