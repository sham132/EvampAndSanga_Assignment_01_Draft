package com.evamp.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "person")
public class person {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String fullName;
	private String gender;
	private Date birthdate;
	private String employeeCode;
	private Date hireDate;
	private Date terminationDate;

	// Constructors
	public person() {
		// Default constructor
	}

	public person(String fullName, String gender, Date birthdate, String employeeCode, Date hireDate,
			Date terminationDate) {
		this.fullName = fullName;
		this.gender = gender;
		this.birthdate = birthdate;
		this.employeeCode = employeeCode;
		this.hireDate = hireDate;
		this.terminationDate = terminationDate;
	}

	// Getters and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(Date birthdate) {
		this.birthdate = birthdate;
	}

	public String getEmployeeCode() {
		return employeeCode;
	}

	public void setEmployeeCode(String employeeCode) {
		this.employeeCode = employeeCode;
	}

	public Date getHireDate() {
		return hireDate;
	}

	public void setHireDate(Date hireDate) {
		this.hireDate = hireDate;
	}

	public Date getTerminationDate() {
		return terminationDate;
	}

	public void setTerminationDate(Date terminationDate) {
		this.terminationDate = terminationDate;
	}

	// Other methods
	@Override
	public String toString() {
		return "Person{" + "id=" + id + ", fullName='" + fullName + '\'' + ", gender=" + gender + ", birthdate="
				+ birthdate + ", employeeCode='" + employeeCode + '\'' + ", hireDate=" + hireDate + ", terminationDate="
				+ terminationDate + '}';
	}
}