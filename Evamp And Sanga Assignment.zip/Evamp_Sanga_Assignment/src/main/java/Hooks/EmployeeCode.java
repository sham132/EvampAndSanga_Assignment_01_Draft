package Hooks;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class EmployeeCode {

	public static String generateEmployeeCode(Date firstWorkDay) {
		// Format the first workday to obtain the YYMMDD part
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyMMdd");
		String yymmdd = dateFormat.format(firstWorkDay);

		// Generate a random order number between 0 and 255 (hexadecimal)
		Random random = new Random();
		int orderNumber = random.nextInt(256); // 0 to 255

		// Convert the order number to a 2-character hexadecimal string
		String orderHex = String.format("%02X", orderNumber);

		// Concatenate the YYMMDD and order number as a string
		String employeeCode = yymmdd + orderHex;

		return employeeCode;
	}

}
