package Hooks;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateStandardization {

	private static final String STANDARD_DATE_FORMAT = "yyyy-MM-dd";

	public static String standardizeDate(String inputDate) {
		// List of possible input formats

		String[] inputFormats = { "MM-dd-yyyy", // Format 1
				"MM/dd/yyyy", // Format 2
				"dd-MMM-yyyy", // Format 3 (e.g., 04-Oct-2023)
				"yyyy-MMM-dd", // Format 3 (e.g., 04-Oct-2023)
				"ddMMyy",
				// Add more formats as needed
		};

		for (String inputFormat : inputFormats) {
			try {
				SimpleDateFormat inputDateFormat = new SimpleDateFormat(inputFormat);
				Date date = inputDateFormat.parse(inputDate);

				SimpleDateFormat outputDateFormat = new SimpleDateFormat(STANDARD_DATE_FORMAT);
				return outputDateFormat.format(date);

			} catch (ParseException e) {
				// Parsing failed, try the next format
			}
		}

		// If none of the formats match, return null or handle the error as needed
		return null;
	}

}
