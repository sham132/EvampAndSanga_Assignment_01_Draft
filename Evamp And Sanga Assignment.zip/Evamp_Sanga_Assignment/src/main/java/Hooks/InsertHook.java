package Hooks;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;

import com.evamp.models.person;
import com.evamp.models.salary_component;
import com.evamp.payloads.Request;
import com.evamp.payloads.SelectData;
import com.evamp.repos.person_repo;
import com.evamp.repos.salary_component_repo;

public class InsertHook {

	public static void Insert(Map<String, String> data1, ResponseEntity<Request> result, person_repo prepo,
			salary_component_repo srepo) throws ParseException {

		// System.out.println(result.getBody().getPayload().get(0).getAction());
		if (prepo.existsByEmployeeCode(result.getBody().getPayload().get(0).getEmployeeCode())) {

			if (result.getBody().getPayload().get(0).getAction().equalsIgnoreCase("update")
					|| result.getBody().getPayload().get(0).getAction().equalsIgnoreCase("change")) {

				List<person> entitiesToUpdate = prepo
						.findByEmplpoyeeCode(result.getBody().getPayload().get(0).getEmployeeCode());

				for (person entity : entitiesToUpdate) {
					entity.setFullName(result.getBody().getFname());
					if (data1.get("person.hire_date") != null) {
						String pattern = "yyyy-MM-dd";

						SimpleDateFormat sdf = new SimpleDateFormat(pattern);
						Date date = sdf.parse(data1.get("person.hire_date"));
						entity.setHireDate(date);
						if (data1.get("person.gender").equalsIgnoreCase("female")) {
							entity.setGender("F");
						} else {
							entity.setGender("M");
						}

					}
				}

				prepo.saveAll(entitiesToUpdate);

			}

		} else if (result.getBody().getPayload().get(0).getAction().equalsIgnoreCase("add")
				|| result.getBody().getPayload().get(0).getAction().equalsIgnoreCase("hire")) {

			String pattern = "yyyy-MM-dd";

			SimpleDateFormat sdf = new SimpleDateFormat(pattern);

			Date date = sdf.parse(data1.get("person.hire_date"));
			Date eDate = sdf.parse(data1.get("person.termination_date"));
			person entity = new person();

			if (data1.get("person.hire_date") != null) {
				entity.setHireDate(date);
			}

			entity.setEmployeeCode(result.getBody().getPayload().get(0).getEmployeeCode());

			entity.setFullName(result.getBody().getFname());

			if (data1.get("person.gender").equalsIgnoreCase("female")) {
				entity.setGender("F");
			} else {
				entity.setGender("M");
			}

			prepo.save(entity);

			salary_component salary = new salary_component();

			salary.setCurrency(result.getBody().getPayload().get(0).getPayComponents().get(0).getCurrency());
			salary.setEndDate(eDate);
			salary.setStartDate(date);

			BigDecimal amount = new BigDecimal(
					result.getBody().getPayload().get(0).getPayComponents().get(0).getAmount());

			salary.setPerson(entity.getId());
			salary.setAmount(amount);

			srepo.save(salary);

		}

	}

}
